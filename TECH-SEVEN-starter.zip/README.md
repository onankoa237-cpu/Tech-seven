# TECH-SEVEN — Starter

Première version visuelle du site TECH-SEVEN, pensée pour le Cameroun et conçue pour évoluer à l'international.

## Contenu actuel
- Page d'accueil responsive en français
- Présentation des cours, formations, bourses, concours et emplois
- Premiers domaines de formation
- Configuration Render Blueprint (`render.yaml`)

## Lancer localement
Prérequis : Node.js 18.17 ou plus récent.

```bash
npm install
npm run dev
```

Ouvrir ensuite http://localhost:3000.

## Déployer sur Render
1. Envoyer tous les fichiers du projet dans un dépôt GitHub.
2. Dans Render, choisir **New +** puis **Blueprint**.
3. Connecter le dépôt GitHub.
4. Vérifier le service décrit dans `render.yaml`, puis lancer le déploiement.

## Important
Cette version est un prototype d'interface : elle ne comporte pas encore de comptes utilisateurs, de base de données, de publication d'offres, de paiement réel ni d'espace administrateur. Ces fonctions devront être ajoutées et testées séparément avant une ouverture au public.
