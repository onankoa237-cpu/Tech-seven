import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TECH-SEVEN | Apprendre. Se former. Réussir.",
  description:
    "Cours scolaires, formations professionnelles, bourses, concours et emplois au Cameroun et dans le monde.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}