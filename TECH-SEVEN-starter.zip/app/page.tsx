const areas = [
  {
    icon: "📘",
    title: "Académie scolaire",
    text: "Des cours organisés par pays, classe, matière et chapitre, avec exercices et corrigés.",
    tag: "Apprendre gratuitement",
  },
  {
    icon: "💻",
    title: "Formation professionnelle",
    text: "Informatique, réseaux, fibre optique, bureautique, génie logiciel et métiers techniques.",
    tag: "Développer ses compétences",
  },
  {
    icon: "🎓",
    title: "Bourses et concours",
    text: "Retrouvez les opportunités, conditions d'admission, dates limites et liens officiels.",
    tag: "Saisir une opportunité",
  },
  {
    icon: "💼",
    title: "Emploi et recrutement",
    text: "Les recruteurs publient leurs offres et les candidats préparent leurs candidatures.",
    tag: "Construire son avenir",
  },
];

const subjects = [
  "Informatique et support",
  "SVT et sciences",
  "Physique, chimie et PCT",
  "Réseaux et fibre optique",
  "Génie civil et technologie",
  "Génie logiciel",
  "Architecture d’intérieur",
  "Word, Excel et PowerPoint",
];

export default function Home() {
  return (
    <main>
      <header className="nav">
        <a className="brand" href="#" aria-label="TECH-SEVEN accueil">
          <span className="brandMark">T7</span>
          <span>TECH<span className="brandAccent">-SEVEN</span></span>
        </a>
        <nav className="navLinks">
          <a href="#academie">Cours</a>
          <a href="#formations">Formations</a>
          <a href="#opportunites">Bourses & emplois</a>
        </nav>
        <a className="navButton" href="#inscription">Rejoindre la plateforme</a>
      </header>

      <section className="hero">
        <div className="heroText">
          <div className="eyebrow"><span className="liveDot" /> L’AVENIR DE L’APPRENTISSAGE</div>
          <h1>Le savoir ouvre<br /><span>toutes les portes.</span></h1>
          <p className="heroLead">
            Apprenez, développez vos compétences et découvrez de nouvelles
            opportunités. Une plateforme éducative pensée au Cameroun, ouverte au monde.
          </p>
          <div className="heroActions">
            <a className="primaryButton" href="#academie">Explorer les cours <span>↗</span></a>
            <a className="secondaryButton" href="#formations">Découvrir les formations</a>
          </div>
          <div className="heroNote"><span>✓</span> Des ressources accessibles pour avancer à votre rythme</div>
        </div>
        <div className="heroPanel">
          <div className="panelTop"><span className="panelLabel">VOTRE PROCHAINE ÉTAPE</span><span className="panelIcon">✦</span></div>
          <div className="panelTitle">Apprendre aujourd’hui.<br />Réussir demain.</div>
          <div className="progressRow"><span>Compétences numériques</span><strong>En pratique</strong></div>
          <div className="progressTrack"><span /></div>
          <div className="miniCards">
            <div><span className="miniIcon blue">⌘</span><strong>Informatique</strong><small>Les fondamentaux</small></div>
            <div><span className="miniIcon gold">✧</span><strong>Opportunités</strong><small>Études et emploi</small></div>
          </div>
          <div className="panelFooter"><span className="avatarStack">● ● ●</span> Une communauté qui progresse ensemble</div>
        </div>
      </section>

      <section className="trustStrip">
        <div><strong>Éducation</strong><span>Comprendre les notions essentielles</span></div>
        <div><strong>Compétences</strong><span>Se préparer au monde professionnel</span></div>
        <div><strong>Opportunités</strong><span>Passer de l’apprentissage à l’action</span></div>
      </section>

      <section className="section" id="academie">
        <div className="sectionHead">
          <div><div className="eyebrow darkEyebrow">UN SEUL ESPACE, PLUSIEURS POSSIBILITÉS</div><h2>Construisez votre avenir<br />avec les bons outils.</h2></div>
          <p>Des contenus clairs, une progression structurée et des informations utiles pour chaque étape de votre parcours.</p>
        </div>
        <div className="featureGrid">
          {areas.map((area) => (
            <article className="featureCard" key={area.title}>
              <div className="featureIcon">{area.icon}</div>
              <h3>{area.title}</h3>
              <p>{area.text}</p>
              <a href="#inscription">{area.tag} <span>→</span></a>
            </article>
          ))}
        </div>
      </section>

      <section className="subjectSection" id="formations">
        <div className="sectionHead subjectHead">
          <div><div className="eyebrow darkEyebrow">APPRENDRE À SON RYTHME</div><h2>Des matières pour<br />aller plus loin.</h2></div>
          <p>Le catalogue sera organisé par niveau, pays, classe et spécialité. Voici les premiers domaines prévus.</p>
        </div>
        <div className="subjectGrid">
          {subjects.map((subject, index) => (
            <div className="subjectItem" key={subject}><span className="subjectNumber">{String(index + 1).padStart(2, "0")}</span><span>{subject}</span><span className="subjectArrow">↗</span></div>
          ))}
        </div>
      </section>

      <section className="opportunity" id="opportunites">
        <div>
          <div className="eyebrow">LE PROCHAIN CHAPITRE COMMENCE ICI</div>
          <h2>Votre prochaine opportunité<br />peut commencer aujourd’hui.</h2>
          <p>Préparez vos études, trouvez une formation ou rapprochez-vous du monde professionnel.</p>
        </div>
        <a className="lightButton" href="#inscription">Découvrir TECH-SEVEN <span>↗</span></a>
      </section>

      <section className="joinSection" id="inscription">
        <div className="joinIcon">T7</div>
        <h2>Le savoir se partage.<br /><span>L’avenir se construit ensemble.</span></h2>
        <p>TECH-SEVEN démarre avec une ambition : rendre l’apprentissage et les opportunités plus accessibles.</p>
        <a className="primaryButton" href="mailto:contact@tech-seven.com?subject=Projet%20TECH-SEVEN">Contacter l’équipe <span>↗</span></a>
        <small>La création de compte et les paiements seront ajoutés dans les prochaines étapes.</small>
      </section>

      <footer className="footer">
        <a className="brand footerBrand" href="#"><span className="brandMark">T7</span><span>TECH<span className="brandAccent">-SEVEN</span></span></a>
        <span>© {new Date().getFullYear()} TECH-SEVEN. Apprendre. Se former. Réussir.</span>
        <span>Une initiative pensée au Cameroun, ouverte au monde.</span>
      </footer>
    </main>
  );
}